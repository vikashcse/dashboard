import { Routes } from '@angular/router';

import { DashboardComponent } from '../../pages/dashboard/dashboard.component';
import { UserProfileComponent } from '../../pages/user-profile/user-profile.component';
import { TablesComponent } from '../../pages/tables/tables.component';

import { ProductsComponent } from 'src/app/pages/products/products.component';
import { CategoryComponent } from 'src/app/pages/category/category.component';
import { UserComponent } from 'src/app/pages/user/user.component';

export const AdminLayoutRoutes: Routes = [
    { path: 'dashboard', component: DashboardComponent },
    { path: 'user-profile', component: UserProfileComponent },
    { path: 'tables', component: TablesComponent },
    { path: 'products', component: ProductsComponent },
    {path:'category',component:CategoryComponent},
    {path:'user',component:UserComponent}
];
