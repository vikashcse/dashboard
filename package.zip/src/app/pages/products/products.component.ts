import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  public allproducts: any;
  allCategory:any;

  product_id = new FormControl('');
  product_name = new FormControl('', [Validators.required]);
  product_sd = new FormControl('');
  product_ld = new FormControl('');
  prise = new FormControl('');
  sale_prise = new FormControl('');
  image = new FormControl('');
  category=new FormControl('');



  getProductUrl = "http://3.142.16.219:4000/vgm/api/products/get_products";
  createProductUrl = "http://3.142.16.219:4000/vgm/api/products/insert_products";
  deletProductUrl = "http://3.142.16.219:4000/vgm/api/products/delete_product";

  getCategoryUrl="http://localhost:4000/vgm/api/category/get_category"
  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.getAllProducts();
    this.getCategory();
  }

  //get all products from db
  getAllProducts() {
    this.http.get(this.getProductUrl).subscribe(data => {
      console.log(data);

      this.allproducts = data;
    })
  }

  //insert new products
  createProduct() {
    //console.log(this.product_id.value, this.product_name.value, this.product_sd.value, this.product_ld.value, this.prise.value,this.sale_prise.value,this.image)
    console.log(this.image)
    let body = {
      "product_id" : this.product_id.value,
      "product_name" : this.product_name.value,
      "product_sd" : this.product_sd.value,
      "product_ld" : this.product_ld.value,
      "prise" : this.prise.value,
      "sale_prise" : this.sale_prise.value,
      "image" : this.image.value,
    }

    this.http.post(this.createProductUrl, body).toPromise().then(data => {
      console.log(data)
    });
    this.getAllProducts()
  }

  edit(id) {
    console.log(id)
  }


  delet(id) {
    let body = {
      "id": id,
    }
    console.log(id)
    this.http.post(this.deletProductUrl, body).subscribe(data => {
      console.log(data);
      this.getAllProducts()
    })
  }

  getCategory(){
    this.http.get(this.getCategoryUrl).toPromise().then(data => {
      console.log(data)
      this.allCategory=data;
    });
  }
}
