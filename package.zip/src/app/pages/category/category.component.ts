import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  createCategoryUrl="http://localhost:4000/vgm/api/category/insert_category"
  getCategoryUrl="http://localhost:4000/vgm/api/category/get_category"
  category_name=new FormControl('')
  description=new FormControl('')
  meta_tag_title=new FormControl('')
  meta_tag_description= new FormControl('')
  meta_tag_keywords=new FormControl('')

  allCategory:any;
  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.getCategory()
  }

  
  getCategory(){
    this.http.get(this.getCategoryUrl).toPromise().then(data => {
      console.log(data)
      this.allCategory=data;
    });
  }


    //insert new Category
    createCategory() {
      //console.log(this.product_id.value, this.product_name.value, this.product_sd.value, this.product_ld.value, this.prise.value,this.sale_prise.value,this.image)

      let body = {
        "category_name" : this.category_name.value,
        "description" : this.description.value,
        "meta_tag_title" : this.meta_tag_title.value,
        "meta_tag_description" : this.meta_tag_description.value,
        "meta_tag_keywords" : this.meta_tag_keywords.value,
      }
      
    this.http.post(this.createCategoryUrl, body).toPromise().then(data => {
      console.log(data)
      this.getCategory()
    });

    }
}
