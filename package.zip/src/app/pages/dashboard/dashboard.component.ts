import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import Chart from 'chart.js';

// core components
import {
  chartOptions,
  parseOptions,
  chartExample1,
  chartExample2
} from "../../variables/charts";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  public datasets: any;
  public dataall: any;
  public salesChart;
  public clicked: boolean = true;
  public clicked1: boolean = false;

  getUserList="http://localhost:5000/api/users/getUserList";
  //getUserList="http://ec2-3-136-22-106.us-east-2.compute.amazonaws.com:5000/list";

  constructor(private http:HttpClient) { }

  ngOnInit() {
    this.getAll()
  }

      // get all from db
      getAll(){
        this.http.get(this.getUserList).subscribe(data=>{
          console.log(data);
          this.dataall=data
        })
      }
  
}
